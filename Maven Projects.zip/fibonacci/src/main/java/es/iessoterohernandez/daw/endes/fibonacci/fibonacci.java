package es.iessoterohernandez.daw.endes.fibonacci;
import java.util.Scanner;
public class fibonacci {
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
       	System.out.print("Introduce cuantas veces se va ha hacer fibonacci: ");
   		int n = sc.nextInt();
   		
   		int a = 0;
   	    int b = 1;
   	   
   	System.out.println("Secuencia de Fibonacci:");
   		for (int i = 0; i < n; i++) {
   			System.out.println(a);
   	        int temp = a;
   	        a = b;
   	        b = temp + b;
   	        }        
    }
}
